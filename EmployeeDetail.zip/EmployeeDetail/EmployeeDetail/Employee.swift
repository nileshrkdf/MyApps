//
//  Employee.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//


// MARK: Protocol

protocol EmployeeProtocol {
    func employeeBenefit(employeeBenefitDetails empDetails : NSDictionary) -> NSDictionary?
}

// MARK: Enum

enum EmploymentType {
    case fullTime
    case Intern
    case resigned
    case contractor
}

// MARK: Structure
struct EmployeeEmploymentDetails {
    var contractStartDate, contractEndDate: String
    var employmentTypeDetail : EmploymentType
    init(contractStartDate conStartDate : String, contractEndDate conEndDate : String, employmentDetails employmentDet : EmploymentType) {
        self.contractStartDate = conStartDate
        self.contractEndDate = conEndDate
        self.employmentTypeDetail = employmentDet
    }
}

import UIKit

// MARK: Class


class Employee: NSObject {
    var empID : Int
    var empName,empAddress : String;
    var empPhoneNo : Int?
    var empDepartment : String?
    
    
    init(employeeID empId : Int, employeeName empName : String, employeeAddress empAddress: String, empPhoneNo empCellNo : Int,employeementDepartment empDepartment : String) {
        self.empID = empId
        self.empName = empName
        self.empAddress = empAddress
        self.empPhoneNo = empCellNo
        self.empDepartment = empDepartment
    }
    init(employeeID empId : Int, employeeName empName : String, employeeAddress empAddress: String) {
        self.empID = empId
        self.empName = empName
        self.empAddress = empAddress
    }
    
    var currentMonthSalary = {(monthlySalary : Int, currentMonthLeaveTaken : Int) -> Int in
        return (monthlySalary - (monthlySalary/30 * currentMonthLeaveTaken))
    }
}

// MARK: Class Extension
extension Employee {
    func printDetails(employeeDetails employee : Employee){
        print("\nEmployee ID -->\(employee.empID) and Employee Name -->\(employee.empName)")
    }
}


// MARK: enum Extension
extension EmploymentType{
    func printEmploymentType(employeeDetails empDetails : EmployeeEmploymentDetails) {
        print("\nEmployment Type -->\(empDetails.employmentTypeDetail)")
    }
}

// MARK: Struct Extension
extension EmployeeEmploymentDetails{
    func printContractEndDate(employeeDetails empDetails : EmployeeEmploymentDetails) -> Void {
        print("\nEmployment contract Endate -->\(empDetails.contractEndDate)")
    }
}

// MARK: Protocol Extension
extension EmployeeProtocol {
    func employeeProjectBenefitDetails(employeeDetails empDetails : Employee) -> NSDictionary?{
        var  dictionary : NSDictionary?
        if let empDepart = empDetails.empDepartment{
            if empDepart == "IT" {
                dictionary = ["HRA": "50%", "LoanFacility": "NO"]
            }else if empDepart == "BPO"{
                dictionary = ["HRA": "20%", "LoanFacility": "YES"]
            }else {
                dictionary = ["HRA": "20%", "LoanFacility": "YES"]
            }
        }
        return dictionary
    }
}
