//
//  Employee.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

protocol EmployeeProtocol {
    func employeeBenefit(employeeBenefitDetails empDetails : NSDictionary) -> NSDictionary?
}
enum EmploymentType {
    case fullTime
    case Intern
    case resigned
    case contractor
}

import UIKit

class Employee: NSObject {
    var empID : Int
    var empName,empAddress : String;
    var empPhoneNo : Int?
    init(employeeID empId : Int, employeeName empName : String, employeeAddress empAddress: String, empPhoneNo empCellNo : Int) {
        self.empID = empId
        self.empName = empName
        self.empAddress = empAddress
        self.empPhoneNo = empCellNo
    }
    init(employeeID empId : Int, employeeName empName : String, employeeAddress empAddress: String) {
        self.empID = empId
        self.empName = empName
        self.empAddress = empAddress
        
    }
    
}
extension Employee {
    func printDetails(employeeDetails employee : Employee){
        print("Employee ID -->\(employee.empID) and Employee Name -->\(employee.empName)")
    }
}
