//
//  Contractor.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit

// MARK: class
class Contractor: Employee, EmployeeProtocol{
    var contractStartDate, contractEndDate: String
    var employmentTypeDetail : EmploymentType
    func employeeBenefit(employeeBenefitDetails empBenefitDetails : NSDictionary) -> NSDictionary?{
        var  dictionary : NSDictionary?
        dictionary = empBenefitDetails
        return dictionary
    }
        // MARK: init()
    init(contractEmployeeDetails employeeEmploymentDetails : EmployeeEmploymentDetails, employeeDetails empDetails : Employee) {
        self.contractStartDate = employeeEmploymentDetails.contractStartDate
        self.contractEndDate = employeeEmploymentDetails.contractEndDate
        self.employmentTypeDetail = employeeEmploymentDetails.employmentTypeDetail
        super.init(employeeID: empDetails.empID, employeeName: empDetails.empName, employeeAddress: empDetails.empAddress,empPhoneNo: empDetails.empPhoneNo!, employeementDepartment : empDetails.empDepartment!)
    }
    override func printDetails(employeeDetails employee: Employee) {
        if let empDepartment = employee.empDepartment {
            print("Contractor employee details Employee ID -->\(employee.empID) || Employee Name -->\(employee.empName) Employee Department -->\(empDepartment)")
        }else{
            print("Contractor employee details Employee ID -->\(employee.empID) and Employee Name -->\(employee.empName)")
        }
        
    }
}
