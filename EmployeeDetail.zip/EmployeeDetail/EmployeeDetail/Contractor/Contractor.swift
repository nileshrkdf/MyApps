//
//  Contractor.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit
extension EmployeeProtocol {
    func employeeProjectDetails(employeeProjectDetails empProjectDetails : NSDictionary) -> NSDictionary?{
        var  dictionary : NSDictionary?
        dictionary = empProjectDetails
        return dictionary
    }
}

class Contractor: Employee, EmployeeProtocol{
    var contractStartDate, contractEndDate: String
    var employmentTypeDetail : EmploymentType
    func employeeBenefit(employeeBenefitDetails empBenefitDetails : NSDictionary) -> NSDictionary?{
        var  dictionary : NSDictionary?
        dictionary = empBenefitDetails
        return dictionary
    }
    init(contractStartDate startDate: String, contractEndDate endDate: String, employmentTypeDetail employmentTypeDet : EmploymentType, employeeDetails empDetails : Employee) {
        self.contractStartDate = startDate
        self.contractEndDate = endDate
        self.employmentTypeDetail = employmentTypeDet
        super.init(employeeID: empDetails.empID, employeeName: empDetails.empName, employeeAddress: empDetails.empAddress,empPhoneNo: empDetails.empPhoneNo!)
    }
    override func printDetails(employeeDetails employee: Employee) {
        print("Contractor employee details Employee ID -->\(employee.empID) and Employee Name -->\(employee.empName)")
    }
}
