//
//  ViewController.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let employee1 = Employee(employeeID: 1, employeeName: "Nilesh", employeeAddress: "2202 Scenic Drive NJ",empPhoneNo: 123456789)
        employee1.printDetails(employeeDetails: employee1)
        
        
        let employee2 = Employee(employeeID: 1, employeeName: "Malviya", employeeAddress: "2202 Scenic Drive NJ",empPhoneNo: 123456789)
        var employeeType = EmploymentType.fullTime
        let fullTimeDetails = EmployeeDetails(contractStartDate: "12/12/2012", contractEndDate: "12/12/2019", employmentDetails: employeeType)
        let fullTimeEmp = FullTimeEmployee(fullTimeEmployeeDetails: fullTimeDetails, employeeDetails: employee2)
        fullTimeEmp.printDetails(employeeDetails: employee2)
        
        
        let employee3 = Employee(employeeID: 2, employeeName: "Intern", employeeAddress: "2202 Scenic Drive NJ")
        employeeType = EmploymentType.Intern
        let internFDetails = EmployeeDetails(contractStartDate: "12/12/2017", contractEndDate: "12/12/2018", employmentDetails: employeeType)
        let internDetails = InternEmployee(internDuration: 2, fullTimeEmployeeDetails: internFDetails, employeeDetails: employee3)
        internFDetails.printContractEndDate(employeeDetails: internFDetails)
        internDetails.printDetails(employeeDetails: employee3)
        
        
    
        let employee4 = Employee(employeeID: 3, employeeName: "Contractor", employeeAddress: "2202 Scenic Drive NJ", empPhoneNo: 2121212121)
        employeeType = EmploymentType.contractor
        let contractorDetails = Contractor(contractStartDate: "12/12/2000", contractEndDate: "12/12/2012", employmentTypeDetail: employeeType, employeeDetails: employee4)
        contractorDetails.printDetails(employeeDetails: employee4)
    
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

