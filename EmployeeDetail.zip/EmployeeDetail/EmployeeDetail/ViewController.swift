//
//  ViewController.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let employee1 = Employee(employeeID: 1, employeeName: "Nilesh", employeeAddress: "2202 Scenic Drive NJ",empPhoneNo: 123456789, employeementDepartment : "IT")
        employee1.printDetails(employeeDetails: employee1)
        
        
        let employee2 = Employee(employeeID: 2, employeeName: "Malviya", employeeAddress: "2202 Scenic Drive NJ",empPhoneNo: 123456789,employeementDepartment : "BPO")
        var employeeType = EmploymentType.fullTime
        let fullTimeEmploymentDetails = EmployeeEmploymentDetails(contractStartDate: "12/12/2012", contractEndDate: "12/12/2019", employmentDetails: employeeType)
        let fullTimeEmp = FullTimeEmployee(fullTimeEmployeeDetails: fullTimeEmploymentDetails, employeeCompleteDetails: employee2)
        fullTimeEmp.printDetails(employeeDetails: employee2)
        fullTimeEmploymentDetails.printContractEndDate(employeeDetails: fullTimeEmploymentDetails)
        let employeeProjectBenefit = fullTimeEmp.employeeProjectBenefitDetails(employeeDetails: employee2)
        print("Project Benefit \(employeeProjectBenefit)")
        
        let employee3 = Employee(employeeID: 3, employeeName: "Intern", employeeAddress: "2202 Scenic Drive NJ")
        employeeType = EmploymentType.Intern
        let internEmploymentDetails = EmployeeEmploymentDetails(contractStartDate: "12/12/2017", contractEndDate: "12/12/2018", employmentDetails: employeeType)
        let internDetails = InternEmployee(internDuration: 2, fullTimeEmployeeDetails: internEmploymentDetails, employeeDetails: employee3)
        internDetails.printDetails(employeeDetails: employee3)
        internEmploymentDetails.printContractEndDate(employeeDetails: internEmploymentDetails)

        
        let employee4 = Employee(employeeID: 4, employeeName: "Contractor", employeeAddress: "2202 Scenic Drive NJ", empPhoneNo: 2121212121, employeementDepartment : "TeleNetworking")
        employeeType = EmploymentType.contractor
        let contractorEmploymentDetails = EmployeeEmploymentDetails(contractStartDate: "12/12/2017", contractEndDate: "12/12/2018", employmentDetails: employeeType)
        let contractorDetails = Contractor(contractEmployeeDetails : contractorEmploymentDetails, employeeDetails: employee4)
        contractorDetails.printDetails(employeeDetails: employee4)
        contractorEmploymentDetails.printContractEndDate(employeeDetails: contractorEmploymentDetails)
        contractorDetails.printDetails(employeeDetails: employee4)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

