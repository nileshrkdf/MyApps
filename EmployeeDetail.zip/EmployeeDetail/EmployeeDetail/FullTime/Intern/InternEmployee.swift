//
//  InternEmployee.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit

// MARK: class
class InternEmployee: FullTimeEmployee {
    var internDuration : Int
    var interDepartment : String?
    
    init(internDuration internDur : Int, fullTimeEmployeeDetails : EmployeeEmploymentDetails, employeeCompleteDetails: Employee ) {
        self.internDuration = internDur
        super.init(fullTimeEmployeeDetails: fullTimeEmployeeDetails, employeeCompleteDetails: employeeCompleteDetails)
    }
    
    init(internDuration internDur : Int, fullTimeEmployeeDetails : EmployeeEmploymentDetails, employeeDetails: Employee ) {
        self.internDuration = internDur
        super.init(fullTimeEmployeeDetails: fullTimeEmployeeDetails, employeeDetails: employeeDetails)
    }
    // MARK: Override functions
    override func employeeBenefit(employeeBenefitDetails empBenefitDetails : NSDictionary) -> NSDictionary?{
        var  dictionary : NSDictionary?
        dictionary = empBenefitDetails
        return dictionary
    }
    
    override func printDetails(employeeDetails employee: Employee) {
        print("Intern employee details Employee ID -->\(employee.empID) and Employee Name -->\(employee.empName)")
    }
}
