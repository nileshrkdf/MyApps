//
//  InternEmployee.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit
extension EmploymentType{
    
}
extension EmployeeDetails{
    func printContractEndDate(employeeDetails empDetails : EmployeeDetails) -> Void {
        print(empDetails.contractEndDate)
    }
}
class InternEmployee: FullTimeEmployee {
    var internDuration : Int
    var interDepartment : String?
    init(internDuration internDur : Int, fullTimeEmployeeDetails : EmployeeDetails, employeeDetails: Employee ) {
        self.internDuration = internDur
        super.init(fullTimeEmployeeDetails: fullTimeEmployeeDetails, employeeDetails: employeeDetails)
    }
    override func employeeBenefit(employeeBenefitDetails empBenefitDetails : NSDictionary) -> NSDictionary?{
        var  dictionary : NSDictionary?
        dictionary = empBenefitDetails
        return dictionary
    }
    override func printDetails(employeeDetails employee: Employee) {
        print("Intern employee details Employee ID -->\(employee.empID) and Employee Name -->\(employee.empName)")
    }
}
