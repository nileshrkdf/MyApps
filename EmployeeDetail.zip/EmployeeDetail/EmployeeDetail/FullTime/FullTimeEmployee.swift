//
//  FullTimeEmployee.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit

// MARK: class
class FullTimeEmployee: Employee,EmployeeProtocol {
    
    var employmentDetail : EmployeeEmploymentDetails
    
    // MARK: Protocol Function
    func employeeBenefit(employeeBenefitDetails empBenefitDetails : NSDictionary) -> NSDictionary?{
        var  dictionary : NSDictionary?
        dictionary = empBenefitDetails
        return dictionary
    }
    
    // MARK: init()
    init(fullTimeEmployeeDetails employeeEmploymentDetails : EmployeeEmploymentDetails, employeeCompleteDetails empDetails : Employee) {
        self.employmentDetail = employeeEmploymentDetails
        super.init(employeeID: empDetails.empID, employeeName: empDetails.empName, employeeAddress: empDetails.empAddress, empPhoneNo : empDetails.empPhoneNo!, employeementDepartment : empDetails.empDepartment!)
    }
    init(fullTimeEmployeeDetails employeeEmploymentDetails : EmployeeEmploymentDetails, employeeDetails empDetails : Employee) {
        self.employmentDetail = employeeEmploymentDetails
        super.init(employeeID: empDetails.empID, employeeName: empDetails.empName, employeeAddress: empDetails.empAddress)
    }
    
    // MARK: Override functions
    override func printDetails(employeeDetails employee: Employee) {
        if let empPhone = employee.empPhoneNo {
            print("FullTime employee details Employee ID -->\(employee.empID) || Employee Name -->\(employee.empName) Employee Phone No -->\(empPhone)")
        }else{
            print("FullTime employee details Employee ID -->\(employee.empID) and Employee Name -->\(employee.empName)")
        }
    }
}
