//
//  FullTimeEmployee.swift
//  EmployeeDetail
//
//  Created by Nilesh on 7/17/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit

struct EmployeeDetails {
    var contractStartDate, contractEndDate: String
    var employmentDetails : EmploymentType
    init(contractStartDate conStartDate : String, contractEndDate conEndDate : String, employmentDetails employmentDet : EmploymentType) {
        self.contractStartDate = conStartDate
        self.contractEndDate = conEndDate
        self.employmentDetails = employmentDet
    }
}

class FullTimeEmployee: Employee,EmployeeProtocol {
    
    var employmentDetail : EmployeeDetails
    
    func employeeBenefit(employeeBenefitDetails empBenefitDetails : NSDictionary) -> NSDictionary?{
        var  dictionary : NSDictionary?
        dictionary = empBenefitDetails
        return dictionary
    }
    init(fullTimeEmployeeDetails employeeEmploymentDetails : EmployeeDetails, employeeDetails empDetails : Employee) {
        self.employmentDetail = employeeEmploymentDetails
        super.init(employeeID: empDetails.empID, employeeName: empDetails.empName, employeeAddress: empDetails.empAddress)
    }
    override func printDetails(employeeDetails employee: Employee) {
        print("Full time employee details Employee ID -->\(employee.empID) and Employee Name -->\(employee.empName)")
    }
}
