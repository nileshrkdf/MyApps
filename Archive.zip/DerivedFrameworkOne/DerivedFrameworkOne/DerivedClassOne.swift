//
//  DerivedClassOne.swift
//  DerivedFrameworkOne
//
//  Created by Nilesh on 7/20/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit
import CommonUtilityFramework

public class DerivedClassOne: CommonFeature,CommonUtilityProtocol {
    public func printDetails() {
        print("Printing from Derived Class One")
    }
    override public func currentMonthSalary(monthlySalary monthSal: Int, currentMonthLeaveTaken leaveTaken: Int) -> Int {
        return (monthSal - (monthSal/30 * leaveTaken) + 2000)
    }
}
