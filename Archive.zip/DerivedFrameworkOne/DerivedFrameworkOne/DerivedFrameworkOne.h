//
//  DerivedFrameworkOne.h
//  DerivedFrameworkOne
//
//  Created by Nilesh on 7/20/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DerivedFrameworkOne.
FOUNDATION_EXPORT double DerivedFrameworkOneVersionNumber;

//! Project version string for DerivedFrameworkOne.
FOUNDATION_EXPORT const unsigned char DerivedFrameworkOneVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DerivedFrameworkOne/PublicHeader.h>


