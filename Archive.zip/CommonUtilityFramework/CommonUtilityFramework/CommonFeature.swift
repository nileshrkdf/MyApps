//
//  CommonFeature.swift
//  CommonUtilityFramework
//
//  Created by Nilesh on 7/19/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit
public protocol CommonUtilityProtocol {
    func printDetails()
}

open class CommonFeature: NSObject {
    open func currentMonthSalary(monthlySalary monthSal : Int, currentMonthLeaveTaken leaveTaken : Int) -> Int {
        return (monthSal - (monthSal/30 * leaveTaken))
    }
}
