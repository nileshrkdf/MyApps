//
//  DerivedClassSecond.swift
//  DerivedFrameworkSecond
//
//  Created by Nilesh on 7/20/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit
import CommonUtilityFramework

public class DerivedClassSecond: CommonFeature {
    public func printDetails() {
        print("Printing from Derived Class Second")
    }
    override public func currentMonthSalary(monthlySalary monthSal: Int, currentMonthLeaveTaken leaveTaken: Int) -> Int {
        return (monthSal - (monthSal/30 * leaveTaken) + 1000)
    }
}
