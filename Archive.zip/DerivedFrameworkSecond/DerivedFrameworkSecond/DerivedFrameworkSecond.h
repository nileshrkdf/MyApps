//
//  DerivedFrameworkSecond.h
//  DerivedFrameworkSecond
//
//  Created by Nilesh on 7/20/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DerivedFrameworkSecond.
FOUNDATION_EXPORT double DerivedFrameworkSecondVersionNumber;

//! Project version string for DerivedFrameworkSecond.
FOUNDATION_EXPORT const unsigned char DerivedFrameworkSecondVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DerivedFrameworkSecond/PublicHeader.h>


