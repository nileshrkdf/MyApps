//
//  ViewController.swift
//  ContainerApp
//
//  Created by Nilesh on 7/19/17.
//  Copyright © 2017 Kanchan. All rights reserved.
//

import UIKit
import DerivedFrameworkOne
import DerivedFrameworkSecond

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let derived1 = DerivedClassOne()
        var currentSalary = derived1.currentMonthSalary(monthlySalary: 10000, currentMonthLeaveTaken: 2)
        derived1.printDetails()
        print("currentSalary \(currentSalary)")
        
        
        let derived2 = DerivedClassSecond()
        currentSalary = derived2.currentMonthSalary(monthlySalary: 10000, currentMonthLeaveTaken: 2)
        derived2.printDetails()
        print("currentSalary \(currentSalary)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

